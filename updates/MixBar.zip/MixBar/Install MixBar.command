#!/bin/bash
# MixBar installer — copies the app to ~/Applications and launches it.
cd "$(dirname "$0")"
fail() {
  echo
  echo "Error $1: $2"
  echo "Look up this code on the MixBar error list:"
  echo "  https://github.com/jonpikereally/TotalMixMenuBar/blob/main/ERRORS.md"
  echo "(You can also give that page to an AI assistant for help.)"
  exit 1
}
echo "Installing MixBar…"
mkdir -p ~/Applications || fail MB-601 "Couldn't create ~/Applications."
rm -rf ~/Applications/MixBar.app
ditto --norsrc MixBar.app ~/Applications/MixBar.app \
  || fail MB-601 "Couldn't copy MixBar into ~/Applications."
# Clear the download quarantine and re-sign locally so macOS trusts it on this Mac.
xattr -dr com.apple.quarantine ~/Applications/MixBar.app 2>/dev/null
codesign --force --sign - ~/Applications/MixBar.app 2>/dev/null \
  || fail MB-602 "Couldn't sign MixBar for this Mac."
open ~/Applications/MixBar.app \
  || fail MB-603 "MixBar was installed but couldn't be opened. Open it from ~/Applications yourself."
echo
echo "Done! Look for the sliders icon in your menu bar."
echo "Grant the Accessibility permission when asked — that lets the volume"
echo "keys control TotalMix. In TotalMix, set OSC to Global OSC (see README.txt)."
