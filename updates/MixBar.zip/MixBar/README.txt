MixBar v1.0 — menu bar control for RME TotalMix FX on macOS (13+)
https://github.com/jonpikereally/TotalMixMenuBar

INSTALL
1. Double-click "Install MixBar.command".
   If macOS blocks it: right-click it, choose Open, then Open again.
2. Grant the Accessibility permission when prompted (System Settings →
   Privacy & Security → Accessibility). This lets the volume keys
   control TotalMix.

SET UP TOTALMIX (FX 2.1 or newer)
1. Options → Settings → OSC tab. Pick a Remote Controller slot, tick In Use.
2. Port incoming 7001, port outgoing 9001, IP or Host Name 127.0.0.1.
3. Compatibility (Mode): Global OSC. Details: tick Send changes, Send status.
4. Tick Send Level Data (for the Levels window).
5. Options → Enable OSC Control must be ticked.

USE
• Click the menu bar icon: output volumes, mute, Comp/EQ, Speaker B, Dim,
  Mono, and 48V / Instrument / Comp / EQ for your inputs
• Volume keys change the chosen TotalMix output (step 1–10 dB, with a
  "never louder than" ceiling); hold Shift+Option for quarter steps
• Mute key = Dim (or mute, in Settings); Shift+Cmd+M = Mono
• Levels window: always-on-top input meters; a name turns red on clipping
  (click to reset)

PRIVACY
MixBar talks only to TotalMix on your own Mac (UDP, 127.0.0.1). No
accounts, no analytics. The only thing it fetches from the internet is a
small version file from the GitHub repo above, to see whether an update
exists.
